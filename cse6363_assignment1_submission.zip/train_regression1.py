import numpy as np
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from LinearRegression import LinearRegression

def main():
    # Load data
    data = fetch_california_housing()
    X, y = data.data, data.target

    # Scale features
    scaler = StandardScaler()
    X = scaler.fit_transform(X)

    # Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Create model with lower learning rate
    model = LinearRegression(learning_rate=0.001, n_iters=1000, l2=0.0)

    model.fit(X_train, y_train)

    test_mse = model.score(X_test, y_test)
    print(f"Test MSE Regression Model 1: {test_mse:.4f}")

    model.save_weights("regression1_weights.pkl")

    plt.plot(model.losses)
    plt.title("Loss Curve for Regression Model 1")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.show()

if __name__ == "__main__":
    main()
