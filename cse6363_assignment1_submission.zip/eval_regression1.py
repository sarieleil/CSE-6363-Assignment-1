import numpy as np
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from LinearRegression import LinearRegression

def main():
    # Load California housing data
    data = fetch_california_housing()
    X, y = data.data, data.target

    # Split train/test sets (match training script split ratio)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Scale features
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    # Initialize model and load trained weights
    model = LinearRegression()
    model.load_weights("regression1_weights.pkl")  # Make sure this file exists

    # Evaluate test set
    test_mse = model.score(X_test, y_test)
    print(f"Evaluation Test MSE Regression Model 1: {test_mse:.4f}")

if __name__ == "__main__":
    main()
