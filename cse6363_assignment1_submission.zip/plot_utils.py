import matplotlib.pyplot as plt

def plot_loss_curve(losses, title="Loss Curve"):
    plt.plot(losses)
    plt.title(title)
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.grid(True)
    plt.show()
