import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from LogisticRegression import LogisticRegression

def main():
    # Load the Iris dataset and use only 2 features and 2 classes
    iris = load_iris()
    X = iris.data
    y = iris.target

    # Keep only class 0 and 1 for binary classification
    idx = y < 2
    X = X[idx]
    y = y[idx]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Load trained model weights
    model = LogisticRegression()
    model.load_weights("classifier2_weights.pkl")

    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Test Accuracy Classifier 2: {accuracy:.4f}")

if __name__ == "__main__":
    main()
