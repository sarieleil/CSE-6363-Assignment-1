import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
import LogisticRegression as lr

def main():
    data = load_iris()
    X = data.data
    y = data.target
    y_binary = (y == 0).astype(int)  # binary classification

    X_train, X_test, y_train, y_test = train_test_split(X, y_binary, test_size=0.2, random_state=42)

    model = lr.LogisticRegression(learning_rate=0.01, n_iters=1000, l2=0.0)
    model.fit(X_train, y_train)

    # Save weights to file for eval to load
    model.save_weights("classifier4_weights.pkl")

    # Optionally evaluate here or use eval script
    y_pred = model.predict(X_test)
    accuracy = np.mean(y_pred == y_test)
    print(f"Train Classifier 4 Accuracy: {accuracy:.4f}")

if __name__ == "__main__":
    main()
