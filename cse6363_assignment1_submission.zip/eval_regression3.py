import numpy as np
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
import LinearRegression as lr

def main():
    # Load diabetes dataset
    data = load_diabetes()
    X = data.data
    y = data.target

    # Split into train and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Initialize the model with correct parameter names
    model = lr.LinearRegression(learning_rate=0.01, n_iters=1000, l2=0.0)

    # Train the model with early stopping enabled
    model.fit(X_train, y_train, early_stopping=True, patience=10)

    # Predict on test set
    y_pred = model.predict(X_test)

    # Calculate MSE score
    mse = model.score(X_test, y_test)
    print(f"Evaluation Test MSE Regression Model 3: {mse:.4f}")

if __name__ == "__main__":
    main()
