import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from LogisticRegression import LogisticRegression

def main():
    data = load_iris()
    X, y = data.data, data.target  # all features, all classes

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    model = LogisticRegression(learning_rate=0.001, n_iters=1000, l2=0.01)
    model.fit(X_train, y_train)

    accuracy = np.mean(model.predict(X_test) == y_test)
    print(f"Test Accuracy Classifier 3: {accuracy:.4f}")

    model.save_weights("classifier3_weights.pkl")

    plt.plot(model.losses)
    plt.title("Loss Curve for Classifier 3")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.show()

if __name__ == "__main__":
    main()
