import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.datasets import fetch_california_housing
from LinearRegression import LinearRegression  # Make sure this file is in the same folder

def main():
    # Load California housing dataset (instead of deprecated Boston)
    housing = fetch_california_housing()
    X = housing.data
    y = housing.target

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Initialize LinearRegression model with learning rate, iterations, and L2 regularization
    model = LinearRegression(learning_rate=0.01, n_iters=1000, l2=0.0)

    # Fit model to training data
    model.fit(X_train, y_train, early_stopping=True, patience=10)

    # Predict on test data and calculate MSE using score method
    test_mse = model.score(X_test, y_test)
    print(f"Test MSE Regression Model 3: {test_mse:.4f}")

    # Save model weights for later use
    model.save_weights("regression3_weights.pkl")

if __name__ == "__main__":
    main()
