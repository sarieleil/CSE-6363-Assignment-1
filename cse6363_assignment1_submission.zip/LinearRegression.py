import numpy as np
import pickle

class LinearRegression:
    def __init__(self, learning_rate=0.01, n_iters=1000, l2=0.0):
        self.learning_rate = learning_rate
        self.n_iters = n_iters
        self.l2 = l2
        self.weights = None
        self.bias = None
        self.losses = []

    def fit(self, X, y, early_stopping=False, patience=10):
        n_samples, n_features = X.shape
        self.weights = np.zeros(n_features)
        self.bias = 0
        best_loss = float('inf')
        patience_counter = 0

        for epoch in range(self.n_iters):
            y_pred = np.dot(X, self.weights) + self.bias
            error = y_pred - y

            # Gradient calculation with L2 regularization
            dw = (1 / n_samples) * np.dot(X.T, error) + (self.l2 / n_samples) * self.weights
            db = (1 / n_samples) * np.sum(error)

            # Update weights and bias
            self.weights -= self.learning_rate * dw
            self.bias -= self.learning_rate * db

            # Calculate loss (MSE + regularization)
            loss = (np.mean(error ** 2) / 2) + (self.l2 / (2 * n_samples)) * np.sum(self.weights ** 2)
            self.losses.append(loss)

            # Early stopping check
            if early_stopping:
                if loss < best_loss:
                    best_loss = loss
                    patience_counter = 0
                else:
                    patience_counter += 1
                    if patience_counter >= patience:
                        print(f"Early stopping at epoch {epoch + 1}")
                        break

    def predict(self, X):
        return np.dot(X, self.weights) + self.bias

    def score(self, X, y):
        y_pred = self.predict(X)
        mse = np.mean((y - y_pred) ** 2)
        return mse

    def save_weights(self, filepath):
        with open(filepath, 'wb') as f:
            pickle.dump({'weights': self.weights, 'bias': self.bias}, f)

    def load_weights(self, filepath):
        with open(filepath, 'rb') as f:
            data = pickle.load(f)
            self.weights = data['weights']
            self.bias = data['bias']
