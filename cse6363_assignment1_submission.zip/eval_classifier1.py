import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from LogisticRegression import LogisticRegression

def main():
    data = load_iris()
    X, y = data.data, data.target

    idx = y < 2
    X, y = X[idx], y[idx]

    scaler = StandardScaler()
    X = scaler.fit_transform(X)

    _, X_test, _, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = LogisticRegression()
    model.load_weights("classifier1_weights.pkl")

    accuracy = np.mean(model.predict(X_test) == y_test)
    print(f"Evaluation Test Accuracy Classifier 1: {accuracy:.4f}")

if __name__ == "__main__":
    main()
